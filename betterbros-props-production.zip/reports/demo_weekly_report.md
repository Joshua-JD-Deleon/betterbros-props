# Backtest Weekly Summary

Generated: 2025-10-11 23:35:29

## Performance Metrics

- **Total Return**: 349.12%
- **Win Rate**: 5.00%
- **Average ROI per Slip**: 349.25%
- **Sharpe Ratio**: 1.892
- **Max Drawdown**: 68.87%
- **Total Slips**: 20
- **Winning Slips**: 1
- **Final Bankroll**: $449.12

## Calibration Analysis

- **Expected Calibration Error (ECE)**: 0.0625
- **Maximum Calibration Error (MCE)**: 0.0904
- **Brier Score**: 0.0512
- **Log Loss**: 0.2206

### Calibration by Probability Bin

| Bin Range | Count | Avg Predicted | Avg Actual | Error |
|-----------|-------|---------------|------------|-------|
| 0.00-0.10 | 5 | 0.090 | 0.000 | 0.090 |
| 0.10-0.20 | 15 | 0.120 | 0.067 | 0.053 |

## Best Performing Slip

- **Slip ID**: 1c417417
- **Legs**: 6
- **Odds**: 89.85
- **Bet**: $5.00
- **Payout**: $449.25
- **ROI**: 8885.02%

## Worst Performing Slip

- **Slip ID**: 690136b9
- **Legs**: 6
- **Odds**: 89.65
- **Bet**: $5.13
- **Payout**: $0.00
- **ROI**: -100.00%

## Performance by Leg Count

| Legs | Slips | Wins | Win Rate | Total Profit | Avg Profit/Slip |
|------|-------|------|----------|--------------|-----------------|
| 6_legs | 20 | 1 | 5.0% | $349.12 | $17.46 |

## Recommendations

- **GOOD ECE**: Model is well-calibrated.
- **LOW WIN RATE**: Consider more conservative slip construction or higher probability thresholds.
- **HIGH DRAWDOWN**: Consider reducing bet sizes or using more conservative Kelly fractions.