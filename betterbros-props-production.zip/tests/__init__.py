"""
Test suite for NFL Props Analyzer.
"""
